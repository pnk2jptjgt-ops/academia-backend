// ============================================================
// نقطة دخول الخادم
// ============================================================
const express = require("express");
const cors = require("cors");
require("dotenv").config();

const authRoutes = require("./routes/auth");
const courseRoutes = require("./routes/courses");
const enrollmentRoutes = require("./routes/enrollment");
const contentRoutes = require("./routes/content");
const examRoutes = require("./routes/exams");

const app = express();

app.use(cors());
app.use(express.json());

// فحص صحة الخادم (تستخدمه Railway للتأكد إن الخادم شغال)
app.get("/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

app.use("/api/auth", authRoutes);
app.use("/api/courses", courseRoutes);
app.use("/api/enrollment", enrollmentRoutes);
app.use("/api/content", contentRoutes);
app.use("/api/exams", examRoutes);

// معالج أخطاء عام — أي خطأ غير متوقع يرجع رسالة واضحة بدل ما الخادم يتوقف
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "حدث خطأ غير متوقع في الخادم" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`الخادم يعمل على المنفذ ${PORT}`);
});
